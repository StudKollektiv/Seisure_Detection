# quick_compare_simple.py
import scipy.io as sio
import matplotlib.pyplot as plt
import numpy as np

#CONFIG: path
human_normal_fp   = r"C:\Users\llore\Documents\Studium\Master_TUD\WS_25_26\Neural_Networks\Project\Data\clips\Volumes\Seagate\seizure_detection\competition_data\clips\Patient_1\Patient_1_interictal_segment_1"
human_seizure_fp  = r"C:\Users\llore\Documents\Studium\Master_TUD\WS_25_26\Neural_Networks\Project\Data\clips\Volumes\Seagate\seizure_detection\competition_data\clips\Patient_1\Patient_1_ictal_segment_1.mat"
canine_normal_fp  = r"C:\Users\llore\Documents\Studium\Master_TUD\WS_25_26\Neural_Networks\Project\Data\clips\Volumes\Seagate\seizure_detection\competition_data\clips\Dog_1\Dog_1_interictal_segment_10.mat"
canine_seizure_fp = r"C:\Users\llore\Documents\Studium\Master_TUD\WS_25_26\Neural_Networks\Project\Data\clips\Volumes\Seagate\seizure_detection\competition_data\clips\Dog_1\Dog_1_ictal_segment_1.mat"

# channel to plot (0-based)
channel = 0

# fallback sample rate (Hz) if file has no 'freq' or 'fs' variable
FALLBACK_FS = 400.0

def load_eeg(path):
    m = sio.loadmat(path)
    # try common names
    if 'data' in m:
        d = m['data']
    elif 'X' in m:
        d = m['X']
    else:
        # pick largest 2D array
        arrays = {k: v for k,v in m.items() if isinstance(v, (np.ndarray,)) and v.ndim==2}
        if not arrays:
            raise ValueError(f"No 2D array found in {path}")
        # choose largest
        key = max(arrays.keys(), key=lambda k: arrays[k].size)
        d = arrays[key]
    d = np.asarray(d, dtype=float)
    # ensure shape channels x samples
    if d.shape[0] < d.shape[1]:
        # likely channels x samples already
        pass
    else:
        # heuristic: if rows >> cols (many channels) keep as is, else transpose
        if d.shape[0] <= 64 and d.shape[1] > d.shape[0]:
            d = d.T
    # sampling rate
    fs = None
    for k in ('freq','fs','sampling_rate'):
        if k in m:
            try:
                fs = float(np.squeeze(m[k]))
                break
            except:
                pass
    if fs is None:
        fs = FALLBACK_FS
    return d, fs

def plot_wave(ax, data, fs, ch, title):
    t = np.arange(data.shape[1]) / fs
    ax.plot(t, data[ch, :])
    ax.set_title(title)
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Amplitude")

def main():
    files = [
        (human_normal_fp,  "Human — Normal"),
        (human_seizure_fp, "Human — Seizure"),
        (canine_normal_fp, "Canine — Normal"),
        (canine_seizure_fp,"Canine — Seizure"),
    ]

    loaded = []
    for fp, label in files:
        try:
            d, fs = load_eeg(fp)
            loaded.append((d, fs, label, fp))
        except Exception as e:
            print("Failed to load", fp, ":", e)
            loaded.append((None, None, label, fp))

    fig, axes = plt.subplots(4, 1, figsize=(10, 8), sharex=True)
    for ax, (d, fs, label, fp) in zip(axes, loaded):
        if d is None:
            ax.text(0.5, 0.5, f"Cannot load\n{fp}", ha='center', va='center')
            ax.set_xticks([])
            ax.set_yticks([])
            continue
        # clamp channel index
        ch = min(channel, d.shape[0]-1)
        plot_wave(ax, d, fs, ch, label)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()