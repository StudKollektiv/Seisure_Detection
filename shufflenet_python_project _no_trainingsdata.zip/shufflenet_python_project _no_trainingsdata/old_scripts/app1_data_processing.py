""" Adapt the data-set to the pre trained image models: 
    Approach 1 : Use fft to convert the eeg data to a suitable image.
"""

import os
import io
import random
import shutil
from pathlib import Path

import numpy as np
import scipy.io
from scipy.signal import stft

import torch
from PIL import Image

# TorchVision models & transforms
from torchvision.models import shufflenet_v2_x0_5, ShuffleNet_V2_X0_5_Weights

#load the ShuffleNet V2 transforms 
weights = ShuffleNet_V2_X0_5_Weights.IMAGENET1K_V1
preprocess = weights.transforms()


#divide data into 80% training and 20% test 
def divide_data(path):

    BASE_DIR = path

    source_dir = BASE_DIR / "Dog_1"
    train_data_dir = BASE_DIR / "datafiles" / "training_data"
    test_data_dir  = BASE_DIR / "datafiles" / "test_data"

    if not os.path.exists(source_dir):
        raise FileNotFoundError(f"Source directory does not exist: {source_dir}")
    
    for d in [train_data_dir, test_data_dir]:
        if os.path.isdir(d):
            shutil.rmtree(d)
        os.makedirs(d, exist_ok=True)
    
    all_files = [f for f in os.listdir(source_dir)
                 if f.startswith("Dog_1_ictal") or f.startswith ("Dog_1_interictal")]
    
    random.shuffle(all_files)

    split_idx = int(len(all_files)*0.8)
    train_files = all_files[:split_idx]
    test_files = all_files[split_idx:]

    for f in train_files:
        src = os.path.join(source_dir, f)
        dst = os.path.join(train_data_dir, f)
        shutil.copy(src, dst)

    for f in test_files:
        src = os.path.join(source_dir, f)
        dst = os.path.join(test_data_dir, f)
        shutil.copy(src, dst)

    print(f"Total files: {len(all_files)}")
    print(f"Training: {len(train_files)} files in {train_data_dir}")
    print(f"Test: {len(test_files)} files in {test_data_dir}")


##convert time data into an frequency-time image via stft
def eeg_data_to_image(eeg, fs = 400):

    num_channels = eeg.shape[0]
    stft_list = []

    for i in range(num_channels): 
        f, t , Zxx = stft(eeg[i], fs = fs, nperseg=64, noverlap=32)
        Sxx = np.abs(Zxx)
        #normalize to [0, 255] for image 
        Sxx = 255 * (Sxx - np.min(Sxx))/(np.max(Sxx) - np.min(Sxx) + 1e-8)
        stft_list.append(Sxx)
    
    combined = np.vstack(stft_list)
    img = Image.fromarray(combined.astype(np.uint8)).convert("RGB")
    return img 

## convert image to tensor 
def convert_to_tensor(folder_path, fs=400): 

    mat_files = [f for f in os.listdir(folder_path) if f.endswith('.mat')]
    tensor = [] 

    for f_name in mat_files: 
        mat_path = os.path.join(folder_path, f_name)
        mat = scipy.io.loadmat(mat_path)
        eeg = mat['data']
        img = eeg_data_to_image(eeg, fs=fs)
        t = preprocess(img)
        tensor.append(t)

    batch_tensor = torch.stack(tensor)
    return batch_tensor 

## extract label from files 
def extract_label(filename): 
    fname = filename.lower() 
    if "seizure" in fname: 
        return 1 
    elif "interictal" in fname: 
        return 0
    else: 
        raise ValueError(f"Cannot detrmine label from filename: {filename}")
    

base_path = Path(__file__).parent
divide_data(base_path)
folder_path = base_path / "datafiles" / "training_data"
image_tensor = convert_to_tensor(folder_path)
print ("Tensor shape for ShuffleNet V2:", image_tensor.shape)