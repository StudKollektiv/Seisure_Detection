from library.processing_utils import * 
from library.model_trainer import * 
from library.data_loader import * 
import torch 
from torch.utils.data import DataLoader


BASE_DIR = Path(r"C:\Users\llore\Documents\Studium\Master_TUD\WS_25_26\Neural_Networks\Project")
source_dir = BASE_DIR / "used_datasets"/"Dog_1"
save_dir = BASE_DIR / "models"/"fft"/"best_model.pth"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
NUM_EPOCHS = 15

if __name__ == "__main__": 
    #group trainingsdate into test and training data
    train_files, test_files = get_train_test_datasets(source_dir)
    #preprocess data 
    train_data = EEGDataset(train_files, transform=fft_grid_transform)
    test_data = EEGDataset(test_files, transform=fft_grid_transform)
    #load 
    train_loader = DataLoader(train_data,batch_size=16,shuffle=True)
    test_loader = DataLoader(test_data,batch_size=16,shuffle=False)
    model = get_shuffle_model()
    criterion = get_criterion()
    optimizer = get_optimizer(model)
    epochs = NUM_EPOCHS
    print(f"\nStarting training on {device}...")
    run_training(device,model,train_loader,test_loader,criterion,optimizer,epochs,save_dir)