from library.processing_utils import * 
from library.model_trainer import * 
from library.data_loader import * 
import torch 
from torch.utils.data import DataLoader
from pathlib import Path


BASE_DIR = Path(r"C:\Users\llore\Documents\Studium\Master_TUD\WS_25_26\Neural_Networks\Project")
train_file_paths =["Dog_1","Dog_2","Dog_3"]
source_dir_path = [BASE_DIR / "used_datasets"/ folder for folder in train_file_paths ]
save_dir = BASE_DIR / "models"/"sample_and_stack"/"best_model_bigger_dataset.pth"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
NUM_EPOCHS = 15

if __name__ == "__main__": 
    #group trainingsdate into test and training data
    train_files, test_files = get_train_test_datasets(source_dir_path)
    #preprocess data 
    train_data = EEGDataset(train_files, transform=downsample_and_stack_transform)
    test_data = EEGDataset(test_files, transform=downsample_and_stack_transform)
    #load 
    train_loader = DataLoader(train_data,batch_size=16,shuffle=True)
    test_loader = DataLoader(test_data,batch_size=16,shuffle=False)
    model = get_shuffle_model()
    criterion = get_criterion()
    optimizer = get_optimizer(model)
    epochs = NUM_EPOCHS
    print(f"\nStarting training on {device}...")
    run_training(device,model,train_loader,test_loader,criterion,optimizer,epochs,save_dir)