""" Adapt the data-set to the pre trained image models: 
    Approach 2 : Intepret the dataset as an image of 16*400 pixels.
    Split the dataset into subgroups and stack them to a for the model suitable tensor. 
    Use a 1x1 convolutional layer as an input adapter to expand the input depth from 1 to 3. 
"""

import random
from pathlib import Path
import numpy as np
import scipy.io
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset
from torchvision.models import shufflenet_v2_x0_5, ShuffleNet_V2_X0_5_Weights
from torch.utils.data import DataLoader

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
EPOCHS = 15


BASE_DIR = Path(r"C:\Users\llore\Documents\Studium\Master_TUD\WS_25_26\Neural_Networks\Project\python_prog_mod_train")
source_dir = BASE_DIR / "Dog_1"
test_dir = BASE_DIR / "Dog_2"


class EEGDataset(Dataset): 
    def __init__(self, file_paths, transform=None): 
        """
        Docstring for EEGDataset
        : param
        """
        self.file_list = file_paths
        self.transform = transform 
    
    def __len__(self): 
        return len(self.file_list)
    
    def __getitem__(self, idx): 
        file_path = self.file_list[idx]
        mat_data = scipy.io.loadmat(file_path)

        #extract data
        eeg_array = mat_data['data'].astype(np.float32)

        #normalize 
        eeg_array = (eeg_array - np.mean(eeg_array))/(np.std(eeg_array)+1e-8)
        eeg_tensor = torch.from_numpy(eeg_array).unsqueeze(0) #[1,16,400]

        ##slice and stack 
        if self.transform: 
            eeg_tensor = self.transform(eeg_tensor)
        
        #label 
        label = 1 if "ictal" in file_path.name and "interictal" not in file_path.name else 0

        return eeg_tensor, label 
    
    
def slice_and_stack_eeg(eeg_tensor): 
    """
    Transforms [1, 16, 400] EEG Data into a [1, 224, 224] stacked image. 
    
    :param eeg_tensor: Description
    """
    #1.slivce the 400 timepoints into 14 segments of 28 pixels (14*28 = 392)
    #Truncate the last 8 pixels of the 400 to keep it even
    segments = torch.split(eeg_tensor[:,:,:392], 28, dim=2)

    #stack segments vertically 
    stacked = torch.cat(segments, dim=1)

    #pad the width from 28 to 224 to make it square 
    final_image = F.pad(stacked, (0,196,0,0), mode='constant',value=0)

    return final_image


#divide data into 80% training and 20% test 
def get_train_test_datasets(source_dir, split_ratio=0.8, transform=None):
    source_path = Path(source_dir)
    
    # Get all relevant files as Path objects
    all_files = [f for f in source_path.glob("*.mat") 
                 if "ictal" in f.name or "interictal" in f.name]
    
    random.shuffle(all_files)

    # Calculate split
    split_idx = int(len(all_files) * split_ratio)
    train_files = all_files[:split_idx]
    test_files = all_files[split_idx:]

    # Create two dataset instances pointing to the same source folder
    train_ds = EEGDataset(train_files, transform=transform)
    test_ds  = EEGDataset(test_files, transform=transform)

    print(f"Dataset Split: {len(train_ds)} Train, {len(test_ds)} Test")
    return train_ds, test_ds


def my_transform(x): 
    #slice and stack 
    x = slice_and_stack_eeg(x)
    #repeat for 3 channels (RGB) for ShuffleNet
    return x.repeat(1,3,1,1).squeeze(0)


def get_model():
    # Load pre-trained weights
    weights = ShuffleNet_V2_X0_5_Weights.IMAGENET1K_V1
    model = shufflenet_v2_x0_5(weights=weights)

    # ShuffleNet V2 x0.5 has a final layer called 'fc'
    # We need to change it from 1000 classes (ImageNet) to 2 classes (EEG)
    num_ftrs = model.fc.in_features
    model.fc = nn.Linear(num_ftrs, 2)
    
    return model


def train_one_epoch(model, train_loader, criterion, optimizer):
    model.to(device)
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0
    
    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        
        # 1. Forward pass
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        
        # 2. Backward pass (Learning)
        loss.backward()
        optimizer.step()
        
        # 3. Statistics
        running_loss += loss.item()*images.size(0)
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()
            
    epoch_loss = running_loss / total
    epoch_acc = 100 * correct / total
    return epoch_loss, epoch_acc


def validate_model(model, test_loader, criterion):
    model.eval() # Set to evaluation mode (turns off dropout/batchnorm)
    running_loss = 0.0
    correct = 0
    total = 0
    
    with torch.no_grad(): # Disable gradient calculation for speed/memory
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            
            outputs = model(images)
            loss = criterion(outputs, labels)
            
            running_loss += loss.item()* images.size(0)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            
    val_loss = running_loss / total
    val_acc = 100 * correct / total
    return val_loss, val_acc


# --- MAIN EXECUTION ---
if __name__ == "__main__":
    # 1. Setup Datasets
    # This uses your get_train_test_datasets function
    train_ds, test_ds = get_train_test_datasets(source_dir, split_ratio=0.8, transform=my_transform)

    if train_ds and test_ds:
        # 2. Create DataLoaders
        train_loader = DataLoader(train_ds, batch_size=16, shuffle=True)
        test_loader = DataLoader(test_ds, batch_size=16, shuffle=False)

        # 3. Initialize Model, Criterion, and Optimizer
        model = get_model()
        criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

        # 4. Training Loop
        # We will run training and then validate after each epoch
        num_epochs = EPOCHS
        print(f"\nStarting training on {device}...")

        best_val_loss = float('inf')
        patience = 3 
        trigger_times = 0
        
        for epoch in range(num_epochs):
            # Train for one epoch
            train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer)
            
            # Validate after the epoch
            val_loss, val_acc = validate_model(model, test_loader, criterion)
            
            print(f"Epoch [{epoch+1}/{num_epochs}]")
            print(f"Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.2f}%")
            print(f"Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.2f}%")
            print("-" * 30)

            if val_loss < best_val_loss: 
                best_val_loss = val_loss 
                trigger_times = 0
                torch.save(model.state_dict(),"best_model.pth")
            else: 
                trigger_times +=1
                if trigger_times >= patience: 
                    print("Early stopping! No improvement for 3 epochs")
                    break 

        print("Model saved as eeg_shufflenet_model.pth")
