import sys
import os
from pathlib import Path

current_dir = Path(__file__).resolve().parent
parent_dir = current_dir.parent
sys.path.append(str(parent_dir))

from library.model_trainer import *
from library.processing_utils import * 
from library.data_loader import *
from library.model_evaluation import *
from torch.utils.data import DataLoader
from pathlib import Path

#please change settings here to test specified model
#time_segment
#fft
MODEL = "time_segment"
TEST_DATA = ["Dog_2"]
# 1 for time segments 
# 2 for square_grid_transform
# 3 for fft 
# 3 for sampling and segmenting
FN = 2
#####################################################

BASE_DIR = Path(r"C:\Users\llore\Documents\Studium\Master_TUD\WS_25_26\Neural_Networks\Project")
model_path = BASE_DIR /"models"/MODEL/"best_model_bigger_dataset.pth"
test_data_path = [BASE_DIR /"used_datasets"/folder for folder in TEST_DATA]
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")




if __name__ == "__main__":
    #1. Get all files from the folder 
    all_files,_ = get_train_test_datasets(test_data_path,1.0)
    #2. Assign the correct transform
    if FN == 1: 
        transform_fn = time_domain_slice_and_stack
    if FN == 2:  
        transform_fn = fft_grid_transform
    if FN == 3: 
        transform_fn = downsample_and_stack_transform
    #3. Setup Model and Loader
    test_data = EEGDataset(all_files, transform=transform_fn)
    model = get_shuffle_model()
    td_loader = DataLoader(test_data,batch_size=16,shuffle=False)
    test_external_data(device,model,td_loader,model_path)
    run_evaluation_suite(model_path,device,test_data)