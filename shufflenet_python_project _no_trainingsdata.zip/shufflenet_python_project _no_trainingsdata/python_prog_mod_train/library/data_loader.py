import torch
import scipy.io
import numpy as np
from torch.utils.data import Dataset


class EEGDataset(Dataset): 
    def __init__(self, file_paths, transform=None): 
        self.file_list = file_paths
        self.transform = transform 
        self.labels = [1 if "ictal" in f.name and "interictal" not in f.name else 0 for f in file_paths]
    
    def __len__(self): 
        return len(self.file_list)
    
    def __getitem__(self, idx): 
        file_path = self.file_list[idx]
        
        mat_data = scipy.io.loadmat(file_path)
        eeg_array = mat_data['data'].astype(np.float32)

        label = self.labels[idx]

        #apply the transform
        if self.transform: 
            eeg_data = self.transform(eeg_array)
        else:
            eeg_data = torch.from_numpy(eeg_array)

        return eeg_data, label