import torch
import csv
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report, balanced_accuracy_score,f1_score,recall_score, precision_score,accuracy_score
from torch.utils.data import DataLoader
from library.model_trainer import *


def run_evaluation_suite(model_path,device, test_dataset,model_name,process_name,log_path,sampler,CrossEntropy,freeze_state, freeze_values,trainmode, class_names=['Interictal', 'Ictal']): 
    """
    Loads the model stats, visualizes a tensor, calculates the confusion matrix
    and stores the stats to a log file.
    
    :param model_path: Description
    :param device: Description
    :param test_dataset: Description
    :param model_name: Description
    :param process_name: Description
    :param log_path: Description
    :param sampler: Description
    :param CrossEntropy: Description
    :param class_names: Description
    """
    model = get_shuffle_model(weights=None)
    #load model 
    state_dict = torch.load(model_path, map_location=device)
    model.load_state_dict(state_dict)
    model.eval()
    print(f" Model loaded successfully from {model_path}")

    all_preds = []
    all_labels = [] 

    #1.visualize example tensor
    print("Generating Tensor Visualization...")
    example_tensor, example_label = test_dataset[0]
    # Convert (3, H, W) -> (H, W, 3) for plotting
    img_display = example_tensor.permute(1, 2, 0).cpu().numpy()
    plt.figure(figsize=(8, 8))
    plt.imshow(img_display)
    plt.title(f"Example Tensor Input\nLabel: {class_names[example_label]}")
    plt.axis('off')
    plt.show()

    #statistics
    print("Calculating Statistics on Test Set...")
    dataloader = DataLoader(test_dataset, batch_size=32, shuffle=False)
    
    with torch.no_grad():
        for inputs, labels in dataloader:
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    #confusion matrix
    cm = confusion_matrix(all_labels, all_preds)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=class_names, yticklabels=class_names)
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.title('Confusion Matrix: Seizure Detection')
    plt.show()

    #unbalanced accuracy
    unbalanced_acc = accuracy_score(all_labels, all_preds)

    #balanced stats with respect to the under represented ictal files 
    balanced_acc = balanced_accuracy_score(all_labels, all_preds)
    
    print("\n--- HONEST MODEL EVALUATION ---")
    print(f"Balanced Accuracy: {unbalanced_acc:.2%}")
    print(f"Balanced Accuracy: {balanced_acc:.2%}") # This is the one to put in your thesis!

    #final report 
    print("\n" + "="*30)
    print("      FINAL PERFORMANCE      ")
    print("="*30)
    print(classification_report(all_labels, all_preds, target_names=class_names))
    print("\n Log model stats")
    log_model_stats(model_name,process_name,all_labels,all_preds,log_path,sampler, CrossEntropy, freeze_state, freeze_values, trainmode)

    
def log_model_stats(model_name, process_name, y_true, y_pred , log_path, sampler_used, loss_weights, freeze_state, freeze_values, trainmode):
    # Calculate the medical-grade metrics
    b_acc = balanced_accuracy_score(y_true, y_pred)
    acc = accuracy_score(y_true,y_pred)
    f1 = f1_score(y_true, y_pred)
    recall = recall_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred)
    
    with open(log_path, mode='w', newline='') as f:
        f.write("="*50 + "\n")
        f.write(f"DETAILED EXPERIMENT REPORT\n")
        f.write("-" * 50 + "\n")
        f.write(f"{'Model File:':<25} {model_name}\n")
        f.write(f"{'Processing Method:':<25} {process_name}\n")

        # Training Mode Logic
        t_mode_str = "From Scratch" if trainmode else "Normal (Transfer Learning)"
        f.write(f"{'Training Mode:':<25} {t_mode_str}\n")
        
        #add training adjustments
        f.write("-" * 50 + "\n")
        f.write(f"{'WeightedRandomSampler:':<25} {'Enabled' if sampler_used else 'Disabled'}\n")
        
        #loss weights
        f.write(f"{'CrossEntropy Weights:':<25} {'Adjusted (1.0, 5.0)' if loss_weights else 'Equal (1.0, 1.0)'}\n")

        freeze_str = f"Enabled {freeze_values}" if freeze_state else "Disabled"
        f.write(f"{'Freeze State:':<25} {freeze_str}\n")
        
        #result Section
        f.write("-" * 50 + "\n")
        f.write(f"{'Accuracy (Unbalanced):':<25} {acc:.4f} ({acc:.2%})\n")
        f.write(f"{'Balanced Accuracy:':<25} {b_acc:.4f} ({b_acc:.2%})\n")
        f.write(f"{'F1-Score:':<25} {f1:.4f}\n")
        f.write(f"{'Recall (Sensitivity):':<25} {recall:.4f} ({recall:.2%})\n")
        f.write(f"{'Precision:':<25} {precision:.4f}\n")
        f.write("="*50 + "\n")
    
    print(f"Detailed report saved to: {log_path}")
