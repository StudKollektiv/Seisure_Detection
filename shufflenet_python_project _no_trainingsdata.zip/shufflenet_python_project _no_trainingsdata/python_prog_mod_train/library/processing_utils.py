import random
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from scipy.signal import stft
from torchvision import transforms

def slice_and_stack_transform(eeg_array):
    """
    slices the time-series eeg data into segments and combines the slices to a 224x224 tensor. 
    Missing pixels get filled with 0. 
    
    :param source_dir: Description
    :param split_ratio: Description
    :param transform: Description
    """
    # a.Normalize
    eeg_norm = np.zeros_like(eeg_array)
    for i in range(16): 
        ch = eeg_array[i]
        ch_min, ch_max = ch.min(), ch.max()
        eeg_norm[i] = (ch - ch_min) / (ch_max - ch_min + 1e-8)
    
    # b.Convert to tensor
    eeg_tensor = torch.from_numpy(eeg_norm).float().unsqueeze(0) # [1, 16, 400]
    
    # c. Slice and Stack 
    segments = torch.split(eeg_tensor[:, :, :392], 28, dim=2)
    stacked = torch.cat(segments, dim=1)
    final_image = F.pad(stacked, (0, 196, 0, 0), mode='constant', value=0)
    
    # d. Repeat for RGB channels [3, 224, 224]
    rgb_image = final_image.repeat(3, 1, 1) 

    # e. ADD THE SHUFFLENET NORMALIZATION HERE
    # This is the step the webpage was talking about
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                                     std=[0.229, 0.224, 0.225])
    
    return normalize(rgb_image)


def fft_grid_transform(eeg_array):
    """Converts the eeg_aary into a 4x4 spectogram matrix.  """
    fs = 400
    nperseg = 64
    noverlap = 32
    
    stft_list = []
    #a.Generate spectrograms for each channel
    for i in range(16):
        _, _, Zxx = stft(eeg_array[i], fs=fs, nperseg=nperseg, noverlap=noverlap)
        Sxx = np.log1p(np.abs(Zxx))
        # Normalize individual channel
        Sxx = (Sxx - np.min(Sxx)) / (np.max(Sxx) - np.min(Sxx) + 1e-8)
        stft_list.append(Sxx)

    #b.Arrange into a 4x4 grid
    #Each row will contain 4 spectrograms side-by-side
    rows = []
    for i in range(0, 16, 4):
        row = np.hstack(stft_list[i:i+4]) # Combine 4 horizontally
        rows.append(row)
    
    combined_grid = np.vstack(rows) # Combine the 4 rows vertically

    #c.Convert to Tensor and Resize
    grid_tensor = torch.from_numpy(combined_grid).float().unsqueeze(0).unsqueeze(0)
    
    #Resize to 224x224 
    resized = F.interpolate(grid_tensor, size=(224, 224), mode='bilinear')
    #repeat for RGB channels
    # Remove batch dim and repeat for RGB: [3, 224, 224]
    rgb_image = resized.squeeze(0).squeeze(0).repeat(3, 1, 1)

    # d. Apply ShuffleNet ImageNet Normalization
    # THIS IS THE STEP FROM THE WEB DESCRIPTION
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                                     std=[0.229, 0.224, 0.225])
    
    return normalize(rgb_image)

 
def get_train_test_datasets(source_dir_paths, split_ratio=0.8):
    """
    Splits the given data-set into 80% trainingsdata and 20% testdata 
    By changing the split_ration the partition ratio can be adjusted. 
    Used to get the unseen testdata in test_external_data() in model_trainer.py
    
    :param source_dir_paths: Description
    :param split_ratio: Description
    """
    all_files = []
    
    for directory in source_dir_paths: 
        source_path = Path(directory)
        # Get all relevant files as Path objects
        files_in_dir = [f for f in source_path.glob("*.mat") 
        if "ictal" in f.name or "interictal" in f.name]
        all_files.extend(files_in_dir)
    
    random.shuffle(all_files)

    # Calculate split
    split_idx = int(len(all_files) * split_ratio)
    train_files = all_files[:split_idx]
    test_files = all_files[split_idx:]

    # Create two dataset instances pointing to the same source folder
    print(f"Total Files found: {len(all_files)}")
    print(f"Dataset Split: {len(train_files)} Train, {len(test_files)} Test")
    return train_files, test_files

#Isnt used anymore, sampling through 400 values per channel cost to much information. 
def downsample_and_stack_transform(eeg_array, n=4, num_slices=4): 
    """
    Downsamples the data by a factor n and stacks into a grid.
    Data shape: (channels, time ) -> e.g., (16,400)
    
    :param eeg_array: Description
    """
    #sample data 
    data_ds = eeg_array[:, ::n]
    #slice and stack 
    slices = np.array_split(data_ds, num_slices, axis=1)
    stacked = np.concatenate(slices, axis=0)
    #normalize 
    img = torch.tensor(stacked).float()
    img = (img - img.min())/(img.max()-img.min() + 1e-8)
    #add to demesnions 
    img = img.unsqueeze(0).unsqueeze(0)
    #strech and shrink the grid 
    img = torch.nn.functional.interpolate(img, size=(244, 244), mode='bilinear',align_corners=False)
    #delete one dimension
    img = img.squeeze(0)

    return img.repeat(3, 1, 1)


def stack_n_sretch_transform(eeg_array): 
    """
    Converts 16x400 EEG into a 64x100 noramlized tensor. 
    Afterwards it gets streched to a 224x224 image-tensor. 
    
    :param eeg_array: Description
    """
    eeg_norm = np.zeros_like(eeg_array)
    #a.normalize
    for i in range(16): 
        ch = eeg_array[i]
        ch_min, ch_max = ch.min(), ch.max()
        eeg_norm[i] = (ch - ch_min) / (ch_max - ch_min + 1e-8)

    #b. slice and stack (Create a 64x100 Quader)
    blocks = []
    for i in range(16):
        channel_slices = eeg_norm[i].reshape(4, 100)
        blocks.append(channel_slices)
    
    quader_grid = np.vstack(blocks) # Final shape: (64, 100)
    
    #c.Convert to Tensor and Resize to 224x224
    img = torch.tensor(quader_grid).float().unsqueeze(0).unsqueeze(0)
    
    #d.bilinear interpolation used to stretch the image
    img = torch.nn.functional.interpolate(img, size=(224, 224), mode='bilinear', align_corners=False)
    
    # e. Prepare for RGB: Remove extra dims and repeat: [3, 224, 224]
    rgb_image = img.squeeze(0).squeeze(0).repeat(3, 1, 1)

    # f. FINAL STEP: ImageNet Normalization (The "ShuffleNet requirement")
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                                     std=[0.229, 0.224, 0.225])
    
    return normalize(rgb_image)
