import torch
import torch.nn as nn
from torchvision.models import shufflenet_v2_x0_5, ShuffleNet_V2_X0_5_Weights
from torch.utils.data import WeightedRandomSampler
import numpy as np



def get_shuffle_model(weights =ShuffleNet_V2_X0_5_Weights.IMAGENET1K_V1):
    """
    returns the shuffle-net-model with weights from IMAGENET
    
    :param weights: Description
    :return: Description
    :rtype: Adam
    """
    #load pre-trained weights
    weights = ShuffleNet_V2_X0_5_Weights.IMAGENET1K_V1
    model = shufflenet_v2_x0_5(weights=weights)

    #shuffleNet V2 x0.5 has a final layer called 'fc'
    #change it from 1000 classes (ImageNet) to 2 classes (EEG)
    num_ftrs = model.fc.in_features
    model.fc = nn.Linear(num_ftrs, 2)
    
    return model

def get_crossentropy(device, weights=[1.0, 1.0]): 
    """
    Adjusts the loss function values 
    
    :param device: Description
    :param weights: Description
    :return: Description
    :rtype: Adam
    """
    class_weights = torch.tensor(weights,dtype=torch.float).to(device)
    return  nn.CrossEntropyLoss(weight=class_weights)

def get_optimizer(model): 
    """adam optimizer works well with large datasets and uses memory efficiently 
    #and adapts the learning rate for each parameter automatically"""
    return torch.optim.Adam(model.parameters(), lr=0.001)


def train_one_epoch(device, model, train_loader, criterion, optimizer):
    """
    Train one epoche 
    
    :param device: Description
    :param model: Description
    :param train_loader: Description
    :param criterion: Description
    :param optimizer: Description
    """
    model.to(device)
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0
    
    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        
        # 1. Forward pass
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        
        # 2. Backward pass (Learning)
        loss.backward()
        optimizer.step()
        
        # 3. Statistics
        running_loss += loss.item()*images.size(0)
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()
            
    epoch_loss = running_loss / total
    epoch_acc = 100 * correct / total
    return epoch_loss, epoch_acc


def run_training(device, model, train_loader,test_loader, criterion, optimizer, num_epochs,save_dir, patience = 3): 
    """
    Train model with given parameters. Stopp early if val.loss decreases over 3 epochs. 
    
    :param device: Description
    :param model: Description
    :param train_loader: Description
    :param test_loader: Description
    :param criterion: Description
    :param optimizer: Description
    :param num_epochs: Description
    :param save_dir: Description
    :param patience: Description
    """
    best_val_loss = float('inf')
    trigger_times = 0

    for epoch in range(num_epochs):
        #train
        train_loss, train_acc = train_one_epoch(device, model, train_loader, criterion, optimizer)
        
        #validate
        val_loss, val_acc = validate_model(device,model, test_loader, criterion)

        #print progress
        print(f"Epoch [{epoch+1}/{num_epochs}]")
        print(f"  Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.2f}%")
        print(f"  Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.2f}%")
        print("-" * 30)

        #early stopping
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            trigger_times = 0
            torch.save(model.state_dict(), save_dir)
            print("  *** Best model saved! ***")
        else:
            trigger_times += 1
            if trigger_times >= patience:
                print(f"Early stopping at epoch {epoch+1}!")
                break
                
    return model
    
    

def validate_model(device, model, test_loader, criterion):
    """
    validate model 
    
    :param device: Description
    :param model: Description
    :param test_loader: Description
    :param criterion: Description
    """
    model.eval() # Set to evaluation mode (turns off dropout/batchnorm)
    running_loss = 0.0
    correct = 0
    total = 0
    
    with torch.no_grad(): # Disable gradient calculation for speed/memory
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            
            outputs = model(images)
            loss = criterion(outputs, labels)
            
            running_loss += loss.item()* images.size(0)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            
    val_loss = running_loss / total
    val_acc = 100 * correct / total
    return val_loss, val_acc


def test_external_data(device, data_loader,model_path):
    """
    Try the model on unknown data to evaluate the real accuracy.
    
    :param device: Description
    :param data_loader: Description
    :param model_path: Description
    """
    model = get_shuffle_model(weights=None)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.to(device)
    model.eval() 

    correct = 0
    total = 0
    with torch.no_grad(): # Disable gradient calculation to save memory
        for images, labels in data_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    accuracy = 100 * correct / total
    return accuracy


def random_sampler_func(train_data): 
    """
    Random sampler ensures that evenly distributed ictal and interictal
    files are transferred for each epoch. 
    
    :param train_data: Description
    """
    all_labels = train_data.labels
    class_count = np.bincount(all_labels)
    class_weights = 1. / class_count
    sample_weights = [class_weights[label] for label in all_labels]
    sample_weights = torch.DoubleTensor(sample_weights)
    sampler = WeightedRandomSampler(sample_weights, len(sample_weights), replacement=True)
    return sampler


def freezer(model, layers=(1, 3, 4)): 
    """
    Freezes specific stages of ShuffleNet V2.
    layers: tuple of integers (e.g., (1, 3, 4)) representing conv1, stage3, and stage4.
    """
    #map numbers to ShuffleNet internal names
    layer_map = {1: "conv1", 2: "stage2", 3: "stage3", 4: "stage4"}
    target_names = [layer_map[i] for i in layers if i in layer_map]

    #freeze all parameters
    for param in model.parameters(): 
        param.requires_grad = False

    #unfreeze parameters which are not in the list 
    for name, param in model.named_parameters():
        # Always unfreeze the final classifier (fc) and the final conv (conv5)
        if "fc" in name or "conv5" in name:
            param.requires_grad = True
            continue
        
        #make every layer trainable which is not in the list 
        is_targeted = any(target in name for target in target_names)
        if not is_targeted:
            param.requires_grad = True

    #print status
    print(f"Frozen layers: {target_names}")
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Total trainable parameters: {trainable:,}")