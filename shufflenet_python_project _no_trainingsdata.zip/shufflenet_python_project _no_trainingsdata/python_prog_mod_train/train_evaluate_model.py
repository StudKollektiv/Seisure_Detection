from library.processing_utils import * 
from library.model_trainer import * 
from library.data_loader import * 
from library.model_evaluation import *
import torch 
from torch.utils.data import DataLoader
from pathlib import Path

############################please make adjustments here############################################################# 

#change directory path of the project here (wind-style): 
BASE_DIR = Path(r"C:\Users\Lorenz Lorenzen\Documents\Uni\Neural_Networks\shufflenet_python_project")

#please enter model name : 
model_name = "slice_n_stack_adj_sampler_and_cross_entropy_no_freeze_large_dataset_2"

#training on(1) or off(0)
train = 1

#evaluation means to test the model on an unknown dataset and to get the log files. 
#evaluation on (1) or off (0) 
eval = 1

#train model from scratch 
#While learning from scratch is on (1) the epochs, data_size and freeze state 
#will be automatically set. 
#off (0)
train_from_scratch = 0

#random-sampler 
#Ensures that every batch has a roughly 50/50 mix of ictal and interictal data
# on (1) off (0)
random_sampler = 1

#adjust cross entropy [1.0, 5.0]
#ictal gets more influence on the model 
# on(1) off (0)
adjust_cross_entropy = 1

#freeze and unfreeze layers 
#layers chosen are frozen ! 
# 0 for none 
# 1 for Conv1/MaxPool 
# 2 for stage 2 
# 3 for stage 3
# 4 for stage 4 
#fc layer not freezable 
# more than one stage possible (please use tuple)
# freezing on (1) off (0)
freez_state = 0
layer_freeze = (0)

#Processing function 
# 1 for slice and stack (time domain)
# 2 for square grid transformation (time domain)
# 3 for fft (frequenze domain)
processing_fun = 1 

#Dataset size 
# 1 for small (dog_1 train and test) 
# 2 for big   (dog1, dog2, dog3 train and test)
dataset_size = 2

#Change Epochs here 
NUM_EPOCHS = 15

#decice settings (autom)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

#########################################################################################################################################


if train_from_scratch: 
    freez_state = False
    NUM_EPOCHS = 100
    dataset_size = 2 

#set parameters 
if processing_fun == 1: 
    transform_fn = slice_and_stack_transform
    process = "slice_n_stack"
if processing_fun == 2:  
    transform_fn = stack_n_sretch_transform
    process = "slice_n_grid"
if processing_fun == 3: 
    transform_fn = fft_grid_transform
    process = "fft"

DATA_DIR = BASE_DIR / "used_datasets"
MODEL_DIR = BASE_DIR / "models"/process 
LOG_DIR = BASE_DIR / "logs"

if dataset_size == 1: 
    train_file_paths = ["Dog_1"]
    test_file_path = ["Dog_2"]
if dataset_size == 2: 
    train_file_paths =["Dog_1","Dog_2","Dog_3"]
    test_file_path = ["Dog_4"]


#set path
source_dir_path = [DATA_DIR / folder for folder in train_file_paths ]
model_name_pth = model_name + ".pth"
model_name_csv = model_name + ".csv"
model_dir_path = MODEL_DIR /model_name_pth
eval_dir_path = [DATA_DIR / folder for folder in test_file_path]
log_dir_path = LOG_DIR / model_name_csv

if __name__ == "__main__":

    if train: 
        #group trainingsdate into test and training data
        train_files, test_files = get_train_test_datasets(source_dir_path)
        #preprocess data 
        train_data = EEGDataset(train_files, transform=transform_fn)
        test_data = EEGDataset(test_files, transform=transform_fn)
        #load 
        #random sampler
        if random_sampler: 
            train_loader = DataLoader(train_data,batch_size=16,sampler=random_sampler_func(train_data))
        else: 
            train_loader = DataLoader(train_data,batch_size=16,shuffle=True)
        test_loader = DataLoader(test_data,batch_size=16,shuffle=False)
        #load model
        if train_from_scratch: 
            model = get_shuffle_model(weights=None)
        else: 
            model = get_shuffle_model()
        #cross-entropy
        if adjust_cross_entropy: 
            criterion = get_crossentropy(device,[1.0, 5.0])
        else: criterion = get_crossentropy(device)
        #adam optimizer
        optimizer = get_optimizer(model)
        #epochs
        epochs = NUM_EPOCHS
        #freez
        if freez_state: 
            freezer(model, layer_freeze)
        #train model 
        print(f"\nStarting training on {device}...")
        if train_from_scratch: 
            run_training(device,model,train_loader,test_loader,criterion,optimizer,epochs,model_dir_path,patience=NUM_EPOCHS)
        else: 
            run_training(device,model,train_loader,test_loader,criterion,optimizer,epochs,model_dir_path)

    #evaluation of the model 
    if eval: 
        #get the unknown files from the folder 
        all_files,_ = get_train_test_datasets(eval_dir_path,1.0)
        #load model 
        test_data = EEGDataset(all_files, transform=transform_fn)
        td_loader = DataLoader(test_data,batch_size=16,shuffle=False)
        #test the data on the model 
        test_external_data(device,td_loader,model_dir_path)
        #images,log-files etc.
        run_evaluation_suite(
            model_dir_path,
            device,
            test_data,
            model_name,
            process,
            log_dir_path,
            random_sampler,
            adjust_cross_entropy,
            freez_state,
            layer_freeze,
            train_from_scratch
            )

    